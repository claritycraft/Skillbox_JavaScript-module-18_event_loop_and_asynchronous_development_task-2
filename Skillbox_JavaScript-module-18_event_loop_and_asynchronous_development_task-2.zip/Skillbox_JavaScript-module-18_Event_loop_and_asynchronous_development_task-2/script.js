function progress(timeInSeconds) {
  // Минимум 2 секунды
  const time = Math.max(timeInSeconds, 2);
  const bar = document.getElementById("progress-bar");
  const counter = document.getElementById("seconds-counter");

  // Устанавливаем продолжительность анимации в CSS
  bar.style.transitionDuration = `${time}s`;

  // Запускаем анимацию
  requestAnimationFrame(() => {
    bar.style.transform = "scaleX(1)";
  });

  // Счётчик секунд
  let secondsPassed = 0;
  counter.textContent = `Прошло 0 секунд`;

  const intervalId = setInterval(() => {
    secondsPassed++;
    counter.textContent = `Прошло ${secondsPassed} секунд`;

    if (secondsPassed >= time) {
      clearInterval(intervalId);
    }
  }, 1000);
}

// Вызовите прогресс, например, на 5 секунд
document.addEventListener("DOMContentLoaded", () => {
  progress(5);
});
